# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['centipyde',
 'centipyde.request_handlers',
 'centipyde.request_handlers.handlers',
 'centipyde.utils']

package_data = \
{'': ['*'], 'centipyde': ['wordlists/*']}

install_requires = \
['requests>=2.28.2,<3.0.0', 'termcolor>=2.2.0,<3.0.0']

entry_points = \
{'console_scripts': ['centipyde = centipyde.centipyde:main']}

setup_kwargs = {
    'name': 'centipyde',
    'version': '0.4',
    'description': 'Experimental program I made to learn about web enumeration, concurrent python, and programming patterns.',
    'long_description': "# Centipyde\nA little program that is ment to simplify the process of writing web 'hacking' tools for me.\nI'm also using it to experiment with software design concepts and OOP programming, so some things are a bit funky as I am learning while I am making it.\n\n## TODO:\n* Add more modes:\n    * Would be nice with some that did alot of predifined things, like a \n        'quick_fuzz' mode that went through cookies, headers, and URL\n        and fuzzed them with bad chars or something.\n    * A recursive mode or setting.\n\n* Add more options:\n    * Should really have the option of using things like SSL, proxies, etc...\n\n* Save progress:\n    * Could implement it with pickle.\n\n* Make a setup.py:\n    * Stuff to put things where they should be (like putting 'centipyde' somewhere in PATH).\n\n* Add tests.\n\n* Add some documentation.\n    \n* Maybe make a GUI mode?\n    * Would be really cool, but would have to be after everything else is pretty much done.\n",
    'author': 'Z4',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
