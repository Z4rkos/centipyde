# Centipyde
A little program that is ment to simplify the process of writing web 'hacking' tools for me.
I'm also using it to experiment with software design concepts and OOP programming, so some things are a bit funky as I am learning while I am making it.

## TODO:
* Add more modes:
    * Would be nice with some that did alot of predifined things, like a 
        'quick_fuzz' mode that went through cookies, headers, and URL
        and fuzzed them with bad chars or something.
    * A recursive mode or setting.

* Add more options:
    * Should really have the option of using things like SSL, proxies, etc...

* Save progress:
    * Could implement it with pickle.

* Make a setup.py:
    * Stuff to put things where they should be (like putting 'centipyde' somewhere in PATH).

* Add tests.

* Add some documentation.
    
* Maybe make a GUI mode?
    * Would be really cool, but would have to be after everything else is pretty much done.
