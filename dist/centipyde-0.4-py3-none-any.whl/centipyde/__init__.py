
__name__ = "Centipyde"
__version__ = "0.4"
__author__ = "Sokrates Hillestad"
